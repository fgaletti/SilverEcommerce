export interface Category {
    id: number;
    name: string;
    isActive: number;
}
